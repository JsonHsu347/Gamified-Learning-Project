using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CityViewUI : MonoBehaviour
{
    public TextMeshProUGUI moneyText;  // Link to the UI Text element for displaying money

    private void Start()
    {
        UpdateMoneyText(); // Initial update when the scene loads
    }

    private void Update()
    {
        UpdateMoneyText(); // Update the text each frame or based on a trigger for optimization
    }

    private void UpdateMoneyText()
    {
        if (moneyText != null && GameManager.Instance != null)
        {
            moneyText.text = "$" + GameManager.Instance.GetMoney(); // Update money display
        }
    }
}
