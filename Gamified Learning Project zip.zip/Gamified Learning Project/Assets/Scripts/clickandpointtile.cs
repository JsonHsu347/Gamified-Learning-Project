using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ClickAndPointTile : MonoBehaviour, IPointerClickHandler
{
    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("Tile clicked: " + gameObject.name);

        Draggable draggable = FindObjectOfType<Draggable>(); // Get the draggable component in the scene

        if (draggable != null)
        {
            GameObject selectedItem = draggable.GetSelectedItem();
            Debug.Log("Item selected: " + (selectedItem != null ? selectedItem.name : "None"));

            if (selectedItem != null)
            {
                PlaceItem(selectedItem);
                draggable.ClearSelectedItem(); // Clear selection after placing
            }
            else
            {
                Debug.Log("No item selected for placement.");
            }
        }
        else
        {
            Debug.LogWarning("Draggable component not found!");
        }
    }

    private void PlaceItem(GameObject itemPrefab)
    {
        if (itemPrefab == null)
        {
            Debug.LogError("Item prefab is null! Check if prefab reference is missing.");
            return;
        }

        Debug.Log("Attempting to place item: " + itemPrefab.name);
        Vector3 offset = new Vector3(0, 0, 0);
        GameObject placedItem = Instantiate(itemPrefab, transform.position + offset, Quaternion.identity);
        placedItem.transform.SetParent(transform);

        Debug.Log("Placed item: " + itemPrefab.name + " at tile: " + gameObject.name);
    }
}