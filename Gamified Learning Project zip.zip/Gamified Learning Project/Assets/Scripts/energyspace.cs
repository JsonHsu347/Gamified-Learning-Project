using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnergySpace : BoardSpace
{
    public override void OnPlayerLands()
    {
        Debug.Log("Player landed on an Energy space.");
        GameManager.Instance.IncreaseEnergyCapacity(20); // Example effect for energy space
    }
}