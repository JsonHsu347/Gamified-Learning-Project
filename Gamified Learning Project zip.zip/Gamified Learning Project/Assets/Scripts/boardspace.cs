using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardSpace : MonoBehaviour
{
    // Enum to specify the type of space
    public enum SpaceType
    {
        Normal,
        Energy,
        Event,
        CityGrowth
    }

    public SpaceType spaceType; // Variable to hold the type of this board space

    // Virtual method for handling when the player lands on the space, allowing derived classes to override
    public virtual void OnPlayerLands()
    {
        // Default behavior when the player lands on this space (can be empty or generalized)
    }
}