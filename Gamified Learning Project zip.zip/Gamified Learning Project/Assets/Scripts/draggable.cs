using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Draggable : MonoBehaviour, IPointerClickHandler
{
    public GameObject itemPrefab; // Prefab to place on tiles
    private GameObject selectedItem; // Holds currently selected item

    public void OnPointerClick(PointerEventData eventData)
    {
        // Select itemPrefab when clicked
        selectedItem = itemPrefab;
        Debug.Log("Selected item: " + selectedItem.name);
    }

    public GameObject GetSelectedItem()
    {
        return selectedItem;
    }

    public void ClearSelectedItem()
    {
        selectedItem = null; // Clear selected item after placement
        Debug.Log("Item deselected after placement.");
    }
}