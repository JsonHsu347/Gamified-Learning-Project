using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CityGrowthSpace : BoardSpace
{
    public override void OnPlayerLands()
    {
        Debug.Log("Player landed on a City Growth space.");
        GameManager.Instance.IncreasePopulation(100);
    }
}
