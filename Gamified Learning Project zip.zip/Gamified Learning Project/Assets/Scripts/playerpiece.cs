using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPiece : MonoBehaviour
{
    private enum PlayerState { Moving, Stopped }
    private PlayerState currentState = PlayerState.Stopped;

    private void Start()
    {
        // Load saved position from GameManager, if one exists
        if (GameManager.Instance != null && GameManager.Instance.hasSavedPosition)
        {
            transform.position = GameManager.Instance.GetSavedPlayerPosition();
        }
    }

    public void MoveToNextSpace(int diceRoll)
    {
        // Call the GameManager to move the player piece
        GameManager.Instance.MovePlayerPiece(diceRoll);
    }
}