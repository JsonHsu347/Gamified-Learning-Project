using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public Vector3 playerPosition = Vector3.zero;
    public int round = 1;
    public int population = 200;
    public int playerMoney = 2000;
    public int energyCapacity = 100;
    public bool hasSavedPosition = false;

    public event Action OnPopulationChanged;

    private TextMeshProUGUI populationText;
    private TextMeshProUGUI moneyText;
    private TextMeshProUGUI energyText;
    private TextMeshProUGUI roundText;

    public List<BoardSpace> boardSpaces;
    private Dictionary<int, BoardSpace.SpaceType> boardSpaceTypes;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;

            InitializeBoardSpaceTypes(); // Initialize the board space types
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        UpdateUIReferences();
        boardSpaces = new List<BoardSpace>(FindObjectsOfType<BoardSpace>());

        if (scene.name == "Main Menu")
        {
            ResetGame();
        }
        else if (scene.name == "City View")
        {
            SavePlayerPosition(playerPosition);
        }
        else if (scene.name == "Board View" && hasSavedPosition)
        {
            GameObject playerPiece = GameObject.FindWithTag("Player");
            if (playerPiece != null)
            {
                playerPiece.transform.position = GetSavedPlayerPosition();
            }
        }

        UpdatePopulationUI();
        UpdateMoneyUI();
        UpdateEnergyUI();
        UpdateRoundUI();
    }

    private void InitializeBoardSpaceTypes()
    {
        boardSpaceTypes = new Dictionary<int, BoardSpace.SpaceType>
        {
            // Normal spaces
            {1, BoardSpace.SpaceType.Normal}, {2, BoardSpace.SpaceType.Normal}, {4, BoardSpace.SpaceType.Normal},
            {6, BoardSpace.SpaceType.Normal}, {9, BoardSpace.SpaceType.Normal}, {12, BoardSpace.SpaceType.Normal},
            {16, BoardSpace.SpaceType.Normal}, {17, BoardSpace.SpaceType.Normal}, {20, BoardSpace.SpaceType.Normal},
            {24, BoardSpace.SpaceType.Normal}, {25, BoardSpace.SpaceType.Normal}, {26, BoardSpace.SpaceType.Normal},
            {28, BoardSpace.SpaceType.Normal}, {30, BoardSpace.SpaceType.Normal},

            // Energy spaces
            {3, BoardSpace.SpaceType.Energy}, {8, BoardSpace.SpaceType.Energy}, {15, BoardSpace.SpaceType.Energy},
            {18, BoardSpace.SpaceType.Energy}, {19, BoardSpace.SpaceType.Energy}, {31, BoardSpace.SpaceType.Energy},

            // Event spaces
            {5, BoardSpace.SpaceType.Event}, {13, BoardSpace.SpaceType.Event}, {21, BoardSpace.SpaceType.Event},
            {22, BoardSpace.SpaceType.Event}, {29, BoardSpace.SpaceType.Event}, {32, BoardSpace.SpaceType.Event},

            // City Growth spaces
            {7, BoardSpace.SpaceType.CityGrowth}, {10, BoardSpace.SpaceType.CityGrowth}, {11, BoardSpace.SpaceType.CityGrowth},
            {14, BoardSpace.SpaceType.CityGrowth}, {23, BoardSpace.SpaceType.CityGrowth}, {27, BoardSpace.SpaceType.CityGrowth}
        };
    }

    public void MovePlayerPiece(int diceRoll)
    {
        int currentIndex = GetCurrentPlayerIndex();
        int targetIndex = currentIndex + diceRoll;

        if (targetIndex >= 0 && targetIndex < boardSpaces.Count)
        {
            BoardSpace targetBoardSpace = boardSpaces[targetIndex];
            Vector3 targetPosition = targetBoardSpace.transform.position;

            GameObject playerPiece = GameObject.FindWithTag("Player");
            if (playerPiece != null)
            {
                playerPiece.transform.position = targetPosition;
                playerPosition = targetPosition;

                targetBoardSpace.OnPlayerLands();

                HandleBoardSpaceEvent(targetIndex + 1); // Pass the actual space index (1-based)
            }
        }
        else
        {
            Debug.LogWarning("Target index out of bounds. Check boardSpaces list order.");
        }
    }

    public void HandleBoardSpaceEvent(int spaceIndex)
    {
        if (boardSpaceTypes.TryGetValue(spaceIndex, out BoardSpace.SpaceType spaceType))
        {
            switch (spaceType)
            {
                case BoardSpace.SpaceType.Normal:
                    Debug.Log("Player landed on a normal space.");
                    break;

                case BoardSpace.SpaceType.Event:
                    Debug.Log("Player landed on an event space.");
                    TriggerEvent();
                    break;

                case BoardSpace.SpaceType.CityGrowth:
                    Debug.Log("Player landed on a city growth space.");
                    IncreasePopulation(50);
                    break;

                case BoardSpace.SpaceType.Energy:
                    Debug.Log("Player landed on an energy space.");
                    IncreaseEnergyCapacity(10);
                    break;
            }
        }
        else
        {
            Debug.LogWarning("Board space index not found in boardSpaceTypes.");
        }
    }

    private int GetCurrentPlayerIndex()
    {
        for (int i = 0; i < boardSpaces.Count; i++)
        {
            if (Vector3.Distance(boardSpaces[i].transform.position, playerPosition) < 0.1f)
            {
                return i;
            }
        }
        Debug.LogWarning("Player position not found on board. Defaulting to first space.");
        return 0;
    }

    public void SavePlayerPosition(Vector3 position)
    {
        playerPosition = position;
        hasSavedPosition = true;
    }

    public Vector3 GetSavedPlayerPosition()
    {
        return playerPosition;
    }

    public void ResetGame()
    {
        round = 1;
        playerPosition = Vector3.zero;
        hasSavedPosition = false;
        population = 200;
        playerMoney = 2000;
        energyCapacity = 100;

        UpdatePopulationUI();
        UpdateMoneyUI();
        UpdateEnergyUI();
        UpdateRoundUI();
    }

    public void IncreasePopulation(int amount)
    {
        population += amount;
        UpdatePopulationUI();
        OnPopulationChanged?.Invoke();
    }

    public void IncreaseEnergyCapacity(int amount)
    {
        energyCapacity += amount;
        UpdateEnergyUI();
    }

    public int GetRound()
    {
        return round;
    }

    public void IncrementRound()
    {
        round++;
        UpdateRoundUI();
    }

    public void AddMoney(int amount)
    {
        playerMoney += amount;
        UpdateMoneyUI();
    }

    public int GetMoney()
    {
        return playerMoney;
    }

    private void UpdateUIReferences()
    {
        populationText = GameObject.Find("PopulationText")?.GetComponent<TextMeshProUGUI>();
        moneyText = GameObject.Find("MoneyText")?.GetComponent<TextMeshProUGUI>();
        energyText = GameObject.Find("EnergyText")?.GetComponent<TextMeshProUGUI>();
        roundText = GameObject.Find("RoundText")?.GetComponent<TextMeshProUGUI>();
    }

    private void UpdatePopulationUI()
    {
        if (populationText != null)
        {
            populationText.text = "Population: " + population;
        }
    }

    private void UpdateMoneyUI()
    {
        if (moneyText != null)
        {
            moneyText.text = "Money: $" + playerMoney;
        }
    }

    private void UpdateEnergyUI()
    {
        if (energyText != null)
        {
            energyText.text = "Energy Capacity: " + energyCapacity;
        }
    }

    private void UpdateRoundUI()
    {
        if (roundText != null)
        {
            roundText.text = "Round: " + round;
        }
    }

    // New method to handle events triggered by specific spaces
    public void TriggerEvent()
    {
        Debug.Log("Event triggered! Handle specific event logic here.");
        // Insert event logic here. For example, give resources, change population, or any other custom action.
        // You can add checks or apply different logic based on the space type or the player's position.
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
}