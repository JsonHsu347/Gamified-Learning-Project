using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickableWithArrow : MonoBehaviour
{
    public GameObject arrowPrefab;  // The arrow sprite prefab
    private GameObject arrowInstance;
    private Vector3 arrowOffset = new Vector3(-1.0f, 30.0f, 0f);  // Adjust this to place the arrow above the object

    private static ClickableWithArrow currentlySelected;  // Static reference to keep track of the selected object
    private bool isSelected = false;

    void OnMouseDown()
    {
        // Only allow selection if no item is currently selected
        if (!isSelected && (FindObjectOfType<Draggable>().GetSelectedItem() == null))
        {
            SelectObject();
        }
    }

    void SelectObject()
    {
        // Deselect the currently selected object, if any
        if (currentlySelected != null && currentlySelected != this)
        {
            currentlySelected.DeselectObject();
        }

        // Mark this object as selected
        isSelected = true;

        // Set this object as the currently selected object
        currentlySelected = this;

        // Instantiate the arrow if it doesn't exist
        if (arrowInstance == null && arrowPrefab != null)
        {
            // Rotate the arrow 180 degrees on the Z-axis to point it downward
            arrowInstance = Instantiate(arrowPrefab, transform.position + arrowOffset, Quaternion.Euler(0, 0, 180));
            arrowInstance.transform.SetParent(transform);  // Make the arrow a child of the selected object
        }
    }

    void DeselectObject()
    {
        // Mark this object as deselected
        isSelected = false;

        // Destroy the arrow instance when deselected
        if (arrowInstance != null)
        {
            Destroy(arrowInstance);
        }
    }
}