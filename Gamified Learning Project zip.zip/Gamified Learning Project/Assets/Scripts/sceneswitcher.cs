using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitcher : MonoBehaviour
{
    public void LoadCityView()
    {
        // Save player position before switching to City View
        PlayerPiece player = FindObjectOfType<PlayerPiece>();
        if (player != null && GameManager.Instance != null)
        {
            GameManager.Instance.SavePlayerPosition(player.transform.position);
        }

        SceneManager.LoadScene("City View");
    }

    public void LoadBoardView()
    {
        // Only restore position if a saved position exists
        if (GameManager.Instance != null && GameManager.Instance.hasSavedPosition)
        {
            PlayerPiece player = FindObjectOfType<PlayerPiece>();
            if (player != null)
            {
                player.transform.position = GameManager.Instance.GetSavedPlayerPosition();
            }
        }

        SceneManager.LoadScene("Board View");
    }

    public void LoadMainMenu()
    {
        // Reset the game state before returning to the Main Menu
        if (GameManager.Instance != null)
        {
            GameManager.Instance.ResetGame();
        }

        SceneManager.LoadScene("Main Menu");
    }
}