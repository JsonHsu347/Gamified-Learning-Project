using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventSpace : BoardSpace
{
    public override void OnPlayerLands()
    {
        Debug.Log("Player landed on an Event space.");
        TriggerEvent();
    }

    private void TriggerEvent()
    {
        int randomEvent = Random.Range(0, 6);
        switch (randomEvent)
        {
            case 0:
                Debug.Log("Government kickback for solar: Gain $200");
                GameManager.Instance.AddMoney(200);
                break;
            case 1:
                Debug.Log("Bright and sunny summer: Go forward 2 spaces");
                GameManager.Instance.MovePlayerPiece(2);
                break;
            case 2:
                Debug.Log("Successful pilot project: Go forward 2 spaces");
                GameManager.Instance.MovePlayerPiece(2);
                break;
            case 3:
                Debug.Log("Flock of geese flew into wind turbines: Go back 1 space");
                GameManager.Instance.MovePlayerPiece(-1);
                break;
            case 4:
                Debug.Log("New dam built. Ecological disaster ensues: Go back 3 spaces");
                GameManager.Instance.MovePlayerPiece(-3);
                break;
            case 5:
                Debug.Log("Nuclear waste spill: Pay $1000");
                GameManager.Instance.AddMoney(-1000);
                break;
            default:
                Debug.Log("No event triggered.");
                break;
        }
    }
}