using UnityEngine;
using UnityEngine.UI; // Include this for UI elements
using TMPro; // Include this if using TextMeshPro
using System.Collections.Generic; // Needed for List

public class FunFactPopup : MonoBehaviour
{
    public GameObject popupPanel; // Reference to the panel
    public TextMeshProUGUI funFactText; // Reference to the TextMeshPro component (or use Text if you're not using TextMeshPro)

    // List of fun facts
    private List<string> funFacts = new List<string>
    {
        "Did you know? Fossil fuels like coal, petroleum, and natural gas are formed from the remains of ancient plants and animals, some dating back over 300 million years ago!",
        "Did you know? Coal is the largest single source of energy for electricity generation worldwide, providing 36% of glaobal electricity.",
        "Fact: Renewable energy sources accounted for almost 30% of the world's electricity generation in 2022.",
        "Interesting: The amount of solar energy hitting Earth each hour could meet the world's energy needs for an entire year.",
        "Did you know? Wind power is one of the most efficient renewable energy sources, with an energy return on investment of up to 30 times the energy used to create the turbines.",
        "Fun Fact: Hydropower is the oldest form of renewable energy, dating back thousands of years to ancient water wheels.",
        "Fun Fact: Bioenergy can be produced from a variety of sources, including food waste, agricultural residues, and even algae.",
        "Interesting: Radioactive decay generates heat naturally, which can be harnessed for power in spacecraft and remote locations.",
        "Did you know? Fusion, the process that powers the sun, has the potential to provide limitless clean energy.",
        "Fact: Fission reactions produce about a million times more energy than traditional chemical reactions.",
        "Fact: Nuclear power plants have no greenhouse gas emissions during operation, making them a low-carbon energy source.",
        "Did you know? Natural gas is primarily methane and is the cleanest-burning fossil fuel, producing fewer emission than coal or oil.",
        "Interesting: Petroleum is used for more than just fuel; it's also a key ingredient in plastics, cosmetics, and even medicines.",
        "Interesting Stats: The US is one of the top oil producers, competing closely with Saudi Arabia and Russia.",
        "Did you know? Coal has been used as an energy source for thousands of years and it was central to the Industrial Revolution.",
        "Growing Sector: Renewables are the fastest-growing energy sector as they're critical for achieving climate goals.",
        "Fun Fact: Solar panel efficiency has increased by over 400% since the 1950s.",
        "Interesting: China leads in installed wind capacity, followed by the US and Germany.",
        "Fact: Bioenergy is actually considered to be carbon-neutral even though burning bioenergy releases carbon dioxide because the plants absorb carbon dioxide while growing.",
        "Interesting: Iceland generates almost all of its electricity and heating from geothermal energy due to its volcanic landscape.",
        "Fun Fact: Space-based solar power could theoretically deliver 24/7 power by capturing sunlight without atmospheric interference.",
        "Fact: Fossil fuels provide around 80% of the world's primary energy, although they are a major source of greenhouse gasses.",
        "Fact: It's increasingly used for electricity generation due to its lower environmental impact compared to coal.",
        "Longevity: Nuclear reactors can operate for up to 80 years with proper maintenance.",
        "Application: All commercial nuclear power plants use fission to generate electricity.",
        "Challenges: Despite decades of research, no fusion reactor has yet produced more energy than it consumes.",
        "Interesting: A new system, Enhanced Geothermal Systems (EGS) could theoretically provide 100 times the world's energy needs if developed effectively.",
        "Fun Fact: Ocean energy includes tidal, wave, and ocean thermal energy, which together could provide a huge untapped source of power.",
        "Unique: Marine energy is one of the few renewable sources with consistent availability, thanks to tides and ocean currents.",
        "Interesting: Earth Infrared Thermal Radiation is an energy sources that seeks to capture the Earth's natural infrared radiation emitted as it cools at night, a novel approach in energy technologies.",
    };

    private void Start()
    {
        // Ensure the pop-up is not active at start
        popupPanel.SetActive(false);
    }

    // Method to display a random fun fact
    public void ShowRandomFunFact()
    {
        string randomFact = funFacts[Random.Range(0, funFacts.Count)]; // Select a random fun fact
        funFactText.text = randomFact; // Set the fun fact text
        popupPanel.SetActive(true); // Activate the pop-up panel
    }

    // Method to close the pop-up
    public void ClosePopup()
    {
        popupPanel.SetActive(false); // Deactivate the pop-up panel
    }
}