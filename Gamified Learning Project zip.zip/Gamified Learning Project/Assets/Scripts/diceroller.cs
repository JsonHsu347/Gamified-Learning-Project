using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.UI;

public class DiceRoller : MonoBehaviour
{
    public Text resultText;          // Reference to the UI Text element
    public PlayerMovement player;     // Reference to the PlayerMovement script

    public void RollDie()
    {
        int rollResult = Random.Range(1, 7);  // Generates a random number between 1 and 6
        resultText.text = "You rolled a: " + rollResult;  // Updates the UI Text
        Debug.Log("You rolled a: " + rollResult);  // Logs the result in the Console

        // Move the player piece based on the rolled number
        player.MovePlayer(rollResult);
    }
}