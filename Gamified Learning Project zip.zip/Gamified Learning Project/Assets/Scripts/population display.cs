using System.Collections;
using UnityEngine;
using TMPro;

public class PopulationDisplay : MonoBehaviour
{
    public TextMeshProUGUI populationText;

    private void Start()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnPopulationChanged += UpdatePopulationDisplay;
            UpdatePopulationDisplay();
        }
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnPopulationChanged -= UpdatePopulationDisplay;
        }
    }

    private void UpdatePopulationDisplay()
    {
        if (populationText != null && GameManager.Instance != null)
        {
            populationText.text = "Population: " + GameManager.Instance.population;
        }
    }
}