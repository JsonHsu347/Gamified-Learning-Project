using System.Collections;
using UnityEngine;
using TMPro;

public class PlayerMovement : MonoBehaviour
{
    public enum TileType { Normal, Event, CityGrowth, EnergyPlant }

    public int totalTiles = 32;                  // Total number of tiles on the board
    public int currentTile = 0;                  // Player's current tile index
    public Transform[] tilePositions;            // Array of tile transforms for board positions
    public TileType[] tileTypes;                 // Array holding the type of each tile on the board
    public float moveSpeed = 5000f;              // Speed of movement between tiles
    public float pauseDuration = 0.1f;           // Pause duration on each tile
    public TextMeshProUGUI roundText;            // UI Text to display round count
    public TextMeshProUGUI diceRollText;         // UI Text to display dice roll result

    private bool isMoving = false;               // Prevents multiple moves at once

    private void Start()
    {
        // Initialize tileTypes array to match totalTiles if not already set
        if (tileTypes == null || tileTypes.Length != totalTiles)
        {
            tileTypes = new TileType[totalTiles];
            for (int i = 0; i < totalTiles; i++)
            {
                tileTypes[i] = TileType.Normal; // Set default tile type to Normal
            }
        }

        // If there is a saved player position, set the piece there
        if (GameManager.Instance.hasSavedPosition)
        {
            transform.position = GameManager.Instance.GetSavedPlayerPosition();
            currentTile = FindClosestTile(transform.position); // Set the current tile index
        }
        else
        {
            transform.position = tilePositions[currentTile].position;  // Set initial position if no saved position
        }

        UpdateRoundText();
    }

    public void RollAndMove()
    {
        if (isMoving) return;  // Prevent multiple moves while moving

        int diceRoll = Random.Range(1, 7);  // Simulate a dice roll between 1 and 6
        diceRollText.text = "Dice Roll: " + diceRoll;
        MovePlayer(diceRoll);
    }

    public void MovePlayer(int spaces)
    {
        if (isMoving) return; // Prevent multiple calls while moving
        StartCoroutine(MoveToTile(spaces));
    }

    private IEnumerator MoveToTile(int spaces)
    {
        isMoving = true;

        for (int i = 0; i < spaces; i++)
        {
            // Move to the next tile
            currentTile = (currentTile + 1) % totalTiles;

            // Check if a round was completed
            if (currentTile == 0)
            {
                GameManager.Instance.IncrementRound();
                GameManager.Instance.AddMoney(500); // Add $500 to the player�s money on round completion
                UpdateRoundText();
            }

            Vector3 nextTilePosition = tilePositions[currentTile].position;

            // Move smoothly to the next tile
            while (Vector3.Distance(transform.position, nextTilePosition) > 0.1f)
            {
                transform.position = Vector3.MoveTowards(transform.position, nextTilePosition, moveSpeed * Time.deltaTime);
                yield return null;
            }

            // Snap to the exact position of the tile and pause
            transform.position = nextTilePosition;

            // Check tile type and apply effects if necessary
            ApplyTileEffects(tileTypes[currentTile]);

            yield return new WaitForSeconds(pauseDuration);
        }

        isMoving = false;

        // Save the new position in GameManager after completing movement
        GameManager.Instance.SavePlayerPosition(transform.position);
    }

    private void ApplyTileEffects(TileType tileType)
    {
        switch (tileType)
        {
            case TileType.Event:
                GameManager.Instance.AddMoney(Random.Range(-200, 200)); // Example event effect
                Debug.Log("Event tile effect triggered.");
                break;

            case TileType.CityGrowth:
                GameManager.Instance.IncreasePopulation(100); // Increase population by 100
                Debug.Log("CityGrowth tile effect triggered. Population increased.");
                break;

            case TileType.EnergyPlant:
                Debug.Log("Energy Plant tile effect triggered.");
                break;

            case TileType.Normal:
            default:
                Debug.Log("Normal tile, no effect.");
                break;
        }
    }

    private void UpdateRoundText()
    {
        if (roundText != null)
        {
            roundText.text = "Round: " + GameManager.Instance.GetRound();
        }
    }

    private int FindClosestTile(Vector3 position)
    {
        int closestIndex = 0;
        float minDistance = Vector3.Distance(position, tilePositions[0].position);

        for (int i = 1; i < tilePositions.Length; i++)
        {
            float distance = Vector3.Distance(position, tilePositions[i].position);
            if (distance < minDistance)
            {
                minDistance = distance;
                closestIndex = i;
            }
        }

        return closestIndex;
    }
}