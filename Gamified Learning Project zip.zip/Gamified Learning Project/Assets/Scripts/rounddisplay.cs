using UnityEngine;
using TMPro;

public class RoundDisplay : MonoBehaviour
{
    private TextMeshProUGUI roundText; // Reference for round UI text

    private void Start()
    {
        // Attempt to find the round text component in the scene
        roundText = GameObject.Find("RoundText")?.GetComponent<TextMeshProUGUI>();

        if (roundText == null)
        {
            Debug.LogError("RoundText UI element not found. Please check the hierarchy.");
        }
    }

    private void Update()
    {
        UpdateRoundText();
    }

    public void UpdateRoundText()
    {
        // Check if GameManager instance is valid
        if (GameManager.Instance == null)
        {
            Debug.LogError("GameManager instance is null. Make sure GameManager is initialized.");
            return;
        }

        // Ensure roundText is not null before updating
        if (roundText != null)
        {
            roundText.text = "Round: " + GameManager.Instance.GetRound(); // Access GameManager's round
        }
        else
        {
            Debug.LogError("RoundText is null. Cannot update.");
        }
    }
}